// proxy.js — Local backend for Zerodha Multi-Account Dashboard
// Run with: node proxy.js

const http = require('http');
const https = require('https');
const url = require('url');

const PORT = 3001;
const KITE_HOST = 'api.kite.trade';
const KITE_LOGIN_HOST = 'kite.zerodha.com';

// CORS headers
function setCORS(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers',
    'Content-Type, Authorization, X-Kite-Version, X-User-Id, X-Access-Token, X-Api-Key');
}

// Generic forwarder to Kite API
function forwardToKite(req, res, targetHost, targetPath) {
  let body = '';
  req.on('data', chunk => body += chunk);
  req.on('end', () => {
    const apiKey = req.headers['x-api-key'] || '';
    const accessToken = req.headers['x-access-token'] || '';

    const headers = {
      'X-Kite-Version': '3',
      'Content-Type': req.headers['content-type'] || 'application/x-www-form-urlencoded',
      'User-Agent': 'Mozilla/5.0'
    };
    if (apiKey) {
      headers['Authorization'] = `token ${apiKey}:${accessToken}`;
    }

    const options = {
      host: targetHost,
      path: targetPath,
      method: req.method,
      headers
    };

    const proxyReq = https.request(options, proxyRes => {
      let data = '';
      proxyRes.on('data', chunk => data += chunk);
      proxyRes.on('end', () => {
        setCORS(res);
        res.writeHead(proxyRes.statusCode, { 'Content-Type': 'application/json' });
        res.end(data);
      });
    });

    proxyReq.on('error', err => {
      setCORS(res);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ status: 'error', message: err.message }));
    });

    if (body) proxyReq.write(body);
    proxyReq.end();
  });
}

const server = http.createServer((req, res) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    setCORS(res);
    res.writeHead(204);
    return res.end();
  }

  const parsed = url.parse(req.url, true);
  const path = parsed.pathname;

  // Health check — dashboard calls this to detect the proxy
  if (path === '/health' || path === '/ping') {
    setCORS(res);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ status: 'ok', message: 'Proxy running' }));
  }

  // Forward Kite API calls: /kite/* -> https://api.kite.trade/*
  if (path.startsWith('/kite/')) {
    const targetPath = path.replace('/kite', '') + (parsed.search || '');
    return forwardToKite(req, res, KITE_HOST, targetPath);
  }

  // Forward login flow: /login/* -> https://kite.zerodha.com/*
  if (path.startsWith('/login/')) {
    const targetPath = path.replace('/login', '') + (parsed.search || '');
    return forwardToKite(req, res, KITE_LOGIN_HOST, targetPath);
  }

  // Default
  setCORS(res);
  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ status: 'error', message: 'Unknown endpoint' }));
});

server.listen(PORT, () => {
  console.log(`✅ Zerodha Proxy running at http://localhost:${PORT}`);
  console.log(`   Health check: http://localhost:${PORT}/health`);
  console.log(`   Kite API:     http://localhost:${PORT}/kite/...`);
  console.log(`\nKeep this window open while using the dashboard.`);
});
